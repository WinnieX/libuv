void extra();

int main(void) {
  extra();
  return 0;
}
