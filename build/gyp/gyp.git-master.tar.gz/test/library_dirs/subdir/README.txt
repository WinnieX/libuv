Make things live in a subdirectory, to make sure that DEPTH works correctly.
