A place-holder for this Xcode build output directory, so that the
test script can verify that .xcodeproj files are not created in
their normal location by making the src/ read-only, and then
selectively making this build directory writable.
