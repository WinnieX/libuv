void objcpp_fun() { }
